import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router'
import { HttpClientService, Mapping, Field } from '../service/http-client.service';
import * as XLSX from 'ts-xlsx';

@Component({
  selector: 'app-mapping',
  templateUrl: './mapping.component.html',
  styleUrls: ['./mapping.component.css']
})
export class MappingComponent implements OnInit {

  productId: string;
  entities: string[];
  fields : string[];
  fieldVal : string[] ;
  mappings:Mapping[]=[];
  clientId:string;

  arrayBuffer:any;
  file:File;

  constructor(private httpClientService: HttpClientService, private router: ActivatedRoute) {
    this.router.queryParams.subscribe(params => {
      this.productId = params['product'];
      this.clientId  = params['client'];
    });
  }

  ngOnInit() {
    this.httpClientService.getEntities(this.productId).subscribe(
      entityResponse => this.handleSuccessfulResponse(entityResponse),
    );
  }

  handleSuccessfulResponse(entityResponse) {
    this.entities = entityResponse;
  }

  loadFields(moduleId: string) {
    this.httpClientService.getFields(moduleId).subscribe(
      fieldResponse => this.handleSuccessFieldResponse(fieldResponse),
    );
  }

  handleSuccessFieldResponse(fieldResponse) {
    this.fields = fieldResponse;
  }

  incomingfile(event) 
  {
  this.file= event.target.files[0]; 
  }

  Upload() {
    let fileReader = new FileReader();
      fileReader.onload = (e) => {
          this.arrayBuffer = fileReader.result;
          var data = new Uint8Array(this.arrayBuffer);
          var arr = new Array();
          for(var i = 0; i != data.length; ++i) arr[i] = String.fromCharCode(data[i]);
          var bstr = arr.join("");
          var workbook = XLSX.read(bstr, {type:"binary"});
          var first_sheet_name = workbook.SheetNames[0];
          var worksheet = workbook.Sheets[first_sheet_name];
          var jsonObj  = XLSX.utils.sheet_to_json(worksheet,{raw:true});
          var firstObject = jsonObj[0];
          this.fieldVal=[];
          //JSON.stringify(firstObject);
          
          Object.keys(firstObject).forEach(k=>
            {
              this.fieldVal.push(k);
           });
            
          alert(this.fieldVal);
          
      }
      fileReader.readAsArrayBuffer(this.file);
}

loadMapping(fieldVal:string,field:Field){
//alert("field value: "+ fieldVal + " field :" + field + "module");
//var fieldJson = new Field(field['fieldId'], field['fieldName']);
//alert(JSON.stringify({fieldValue: fieldVal, field : fieldJson}));
this.mappings.push(new Mapping(field,fieldVal));
}

save(moduleId:string){
  this.httpClientService.postFieldMapping(this.productId,this.clientId,moduleId,this.mappings).subscribe();
}
}